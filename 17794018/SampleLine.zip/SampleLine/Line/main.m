//
//  main.m
//  Line
//
//

#import <UIKit/UIKit.h>

#import "CMBAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CMBAppDelegate class]));
    }
}
