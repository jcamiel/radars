//
//  CMBAppDelegate.h
//  Line
//
//

#import <UIKit/UIKit.h>

@interface CMBAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
