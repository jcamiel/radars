//
//  FirstViewController.m
//  TestCookie
//
//

#import "FirstViewController.h"

@interface FirstViewController ()

@property (weak, nonatomic) IBOutlet UIWebView *webView;

@end

@implementation FirstViewController


- (void)viewDidLoad {
    [super viewDidLoad];

    NSString *URLString = @"http://cookie.kermit.orange-labs.fr";
    NSURL *URL = [NSURL URLWithString:URLString];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    [self.webView loadRequest:request];
}


- (IBAction)refreshDidTap:(id)sender {
    [self.webView reload];
}


@end
