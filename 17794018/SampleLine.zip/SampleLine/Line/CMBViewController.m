//
//  CMBViewController.m
//  Line
//
//

#import "CMBViewController.h"

@interface CMBViewController ()

@end

@implementation CMBViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
