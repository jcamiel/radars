//
//  CMBViewController.h
//  Line
//
//

#import <UIKit/UIKit.h>

@interface CMBViewController : UIViewController

@end
