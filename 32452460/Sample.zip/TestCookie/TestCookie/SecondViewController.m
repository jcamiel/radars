//
//  SecondViewController.m
//  TestCookie
//
//

#import "SecondViewController.h"

#import <WebKit/WebKit.h>

@interface SecondViewController ()

@property (strong, nonatomic) WKWebView *webView;

@end


@implementation SecondViewController


- (void)viewDidLoad {
    [super viewDidLoad];

    [self addWebView];
    
    NSString *URLString = @"http://cookie.kermit.orange-labs.fr";
    NSURL *URL = [NSURL URLWithString:URLString];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    [self.webView loadRequest:request];
}


- (void)addWebView {
    self.webView = [[WKWebView alloc] init];
    self.webView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.webView];
    
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[_webView]|"
                                                                      options:0
                                                                      metrics:nil
                                                                        views:NSDictionaryOfVariableBindings(_webView)]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[_webView]|"
                                                                      options:0
                                                                      metrics:nil
                                                                        views:NSDictionaryOfVariableBindings(_webView)]];
}


- (IBAction)refreshDidTap:(id)sender {
    [self.webView reload];
}

@end
